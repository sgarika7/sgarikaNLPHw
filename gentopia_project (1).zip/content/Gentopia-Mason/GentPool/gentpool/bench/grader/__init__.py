from .instructed import InstructedGrader
from .gate import GateGrader, BatchGateGrader
from .score import ScoreGrader
from .dojo import DojoGrader
from .base import BaseGrader